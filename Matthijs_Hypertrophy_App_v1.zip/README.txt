MATTHIJS HYPERTROPHY APP

Best use:
1. Unzip this folder.
2. Upload all files to a static host such as GitHub Pages, Netlify, Cloudflare Pages or Vercel.
3. Open the hosted URL in Safari on iPhone.
4. Tap Share > Add to Home Screen.

The app stores workout history locally in the browser on that device.
Use Export to save a JSON backup periodically.

Opening index.html directly from the Files app may display the app, but offline installation and persistent behavior work best from an HTTPS-hosted URL.
